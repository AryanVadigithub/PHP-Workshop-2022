<?php
    echo("Hello World!");
    echo "Happy New Year";
    print("<h1>Vishwas</h1>");
?>

<html>
    <body>
        <h2><?php echo("PHP Workshop"); ?></h2>
    </body>
</html>