<?php
    $var1 = 8;
    $var2 = 5;
    $res = $var1 * $var2;
    
    echo "Variable1 is : $var1<br>";    
    echo "Variable2 is : $var2<br>";
    echo "Result is : $res";

    echo("<pre>");
    echo "Variable1 is : $var1\n";    
    echo "Variable2 is : $var2\n";
    echo "Result is : $res";
?>