<?php
    $str1 = "Hello World!";
    $str2 = "Happy New Year";
    $str3 = $str1.$str2;

    $var1 = 5;
    $var2 = 10;
    $var3 = $var1.$var2;


    echo("$str3<br>");
    echo("$var3<br>");
?>