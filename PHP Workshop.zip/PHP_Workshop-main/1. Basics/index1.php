<?php
echo ("Hello World");
echo ("<h1>Hello World</h1>");
?>

<html>

<body>
    <h2><?php echo ("PHP Workshop"); ?></h2>
</body>

</html>